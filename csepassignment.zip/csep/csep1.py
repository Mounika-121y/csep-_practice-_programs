#program to find whether two strings are anagrams or not

str1="race"
str2="care"
str1=str1.lower()
str2=str2.lower()
if(len(str1)==len(str2))
    sort1=sorted(str1)
    sort2=sorted(str2)
    if(sort1==sort2):
        print(str1+"and"+str2, "are anagram")
    else:
        print(str1+"and"+str2,"are not anagram")
else:
    print("given strings are not anagram
