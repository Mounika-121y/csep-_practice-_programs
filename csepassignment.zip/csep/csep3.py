

##################################################################
#            	        alphabetacoder.com
#   Python program to calculate compound interest using Recursion
##################################################################

# recursive function to compute compound interest
def compound_interest(p0, p, r, n, t, itr):
    # if number of total no of compound reached
    if itr == n * t:
        return (p - p0)
    # calculate interest
    interest = p * (r / (n * 100))
	
    # call function
    return compound_interest(p0, p + interest, r, n, t, itr + 1)

def main():
    # take input of initial principal amount,
    # interest rate, periodicity of compounding and year
    p = float(input("Enter the principal balance = "))
    r = float(input("Enter the interest rate = "))
    n = int(input("Enter compound frequency / year = "))
    t = int(input("Enter the year  = "))
        
    # find the compound interest
    ci = compound_interest(p, p, r, n, t, 0)
        
    # display result upto 2 decimal places
    print("Compound interest = ",round(ci, 2))


# driver code
main()


